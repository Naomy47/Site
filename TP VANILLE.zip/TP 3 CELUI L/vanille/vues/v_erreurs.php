﻿<div class="erreur">
<ul>
<?php
foreach($msgErreurs as $erreur)
	{
 ?>     
	  <li><?=$erreur ?></li>
<?php	  
	}
?>
</ul>
</div>
