<div class="disconnect">
    <a href="index.php?uc=gererProduits&etatGestion=deconnexion">Deconnexion</a>
</div>