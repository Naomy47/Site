<div class="container">
    <h2 class="title-co">Connexion administrateur</h2>
    <form class="loginForm" method="POST" action="?uc=gererProduits&etatLog=process">
        <label class="label-command">Nom d'utilisateur</label>
        <input class="input-command" type="text" name="username" required>
        <label class="label-command">Mot de passe</label>
        <input class="input-command" type="password" name="password" required>
        <input class="btn-co" type="submit" value="Se connecter">
    </form>
</div>