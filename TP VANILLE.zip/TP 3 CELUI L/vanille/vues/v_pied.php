
<div id="pied">
<!-- Images En pied -->
<img src="images/VanilleF.jpg"	alt="Boutique Vanille" title="Boutique Vanille" width="900" height="300" />
</div>