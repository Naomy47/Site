﻿<div id="bandeau">
	<!-- Images En-tête -->
	<div style="text-align: center;">
		<img class="bandeauimg" src="images/Vanille.png" alt="Boutique Vanille" title="Boutique Vanille" width="auto" height="25%" />
	</div>
</div>
<!--  Menu haut-->

<div id="menu">
	<div><a href="index.php?uc=accueil"> Accueil </a></div>
	<div><a href="index.php?uc=voirProduits&action=voirCategories"> Voir le catalogue </a></div>
	<div><a href="index.php?uc=gererPanier&action=voirPanier"> Gérer votre panier </a></div>

</div>