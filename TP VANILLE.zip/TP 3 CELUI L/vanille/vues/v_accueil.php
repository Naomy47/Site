<div id="accueil" style="text-align: center">
    <p>VANILLE La Confiserie toulousaine en ligne</p>
    <br>
    <div class="btn-admin"><a href="?uc=gererProduits">Administrer</a></div>
</div>